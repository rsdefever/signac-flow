#PBS -N SubmissionTest/bundle/ec204b0a7405cc3753db681b48d8eeb78286ef72
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(636b26ebd5ec9548239c297990e1fe11)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 636b26ebd5ec9548239c297990e1fe11

# omp_op(636b26ebd5ec9548239c297990e1fe11)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 636b26ebd5ec9548239c297990e1fe11

