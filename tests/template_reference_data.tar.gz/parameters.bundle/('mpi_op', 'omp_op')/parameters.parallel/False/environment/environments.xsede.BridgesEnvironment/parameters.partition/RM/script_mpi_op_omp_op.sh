#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/0f61b9c400e0c6a9222b644833162cabe17ce64e"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(5bea7f4064798af873fad258b21cf034)
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 5bea7f4064798af873fad258b21cf034

# omp_op(5bea7f4064798af873fad258b21cf034)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 5bea7f4064798af873fad258b21cf034

