#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/36c2f7fba9a4872441a9d0b3dd7514e67dc07a50"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(abd47a2fb2ca273ba881932a57fdc4d7)
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op abd47a2fb2ca273ba881932a57fdc4d7

# omp_op(abd47a2fb2ca273ba881932a57fdc4d7)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op abd47a2fb2ca273ba881932a57fdc4d7

