#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/3a4c6dfa3ab5b3812db69390e40101230b134378"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# mpi_op(0a53cc674a835b8a34a187dece361f03)
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 0a53cc674a835b8a34a187dece361f03

# omp_op(0a53cc674a835b8a34a187dece361f03)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 0a53cc674a835b8a34a187dece361f03

