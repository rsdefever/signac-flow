#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/92b222a8474835eb77f57ab27d7ff2e9cd02d2c1"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/johndoe/project/

# mpi_op(f10cfc6dd4fd8c29187aa1971ff2fd87)
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op f10cfc6dd4fd8c29187aa1971ff2fd87 &

# omp_op(f10cfc6dd4fd8c29187aa1971ff2fd87)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op f10cfc6dd4fd8c29187aa1971ff2fd87 &
wait

