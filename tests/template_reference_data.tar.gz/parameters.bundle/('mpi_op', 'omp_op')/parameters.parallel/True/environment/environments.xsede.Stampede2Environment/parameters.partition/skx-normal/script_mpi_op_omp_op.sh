#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/a173a772b4769db153e13362e51ba16ccd229772"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=9
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# mpi_op(046cd669a3d5d74abbba2662c64a1e0c)
ibrun -n 5 -o 0 task_affinity /usr/local/bin/python generate_template_reference_data.py exec mpi_op 046cd669a3d5d74abbba2662c64a1e0c &

# omp_op(046cd669a3d5d74abbba2662c64a1e0c)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 046cd669a3d5d74abbba2662c64a1e0c &
wait

