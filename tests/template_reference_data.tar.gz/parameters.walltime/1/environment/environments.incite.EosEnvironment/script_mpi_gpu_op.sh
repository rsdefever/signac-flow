#PBS -N SubmissionTe/40c5efdd/mpi_gpu_op/0000/e0e03b77ae1598cb8167f6f3711a25fa
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(40c5efdd19a4c2f25070b7b9336d7249)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 40c5efdd19a4c2f25070b7b9336d7249

