#PBS -N SubmissionTe/64760707/gpu_op/0000/bbd25323b0feab93bd972d244f139efa
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# gpu_op(64760707a0aedec77b482309893f1543)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 64760707a0aedec77b482309893f1543

