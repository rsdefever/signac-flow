#PBS -N SubmissionTe/64760707/omp_op/0000/6938ee2deee1f7cabcc20e6dc943d748
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(64760707a0aedec77b482309893f1543)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 64760707a0aedec77b482309893f1543

