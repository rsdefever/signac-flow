#PBS -N SubmissionTe/52fdf0d6/gpu_op/0000/2386814cd97e12f538536f5000b48b05
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# gpu_op(52fdf0d6321aa97d51c44889afb5756e)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 52fdf0d6321aa97d51c44889afb5756e

