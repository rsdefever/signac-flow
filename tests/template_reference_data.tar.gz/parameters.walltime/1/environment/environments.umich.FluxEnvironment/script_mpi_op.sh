#PBS -N SubmissionTe/52fdf0d6/mpi_op/0000/06cb410cfd71fe73c1c8350173d3d3ef
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=5
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_op(52fdf0d6321aa97d51c44889afb5756e)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 52fdf0d6321aa97d51c44889afb5756e

