#!/bin/bash
#SBATCH --job-name="SubmissionTe/d52fc627/mpi_gpu_op/0000/12e269d4e4391ea7752d72b1c7950f24"
#SBATCH --partition=GPU
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 5
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(d52fc62789278c7532552747230bca38)
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op d52fc62789278c7532552747230bca38

