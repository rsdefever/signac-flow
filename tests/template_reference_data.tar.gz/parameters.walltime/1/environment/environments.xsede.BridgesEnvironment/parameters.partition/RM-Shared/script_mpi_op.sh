#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d2/mpi_op/0000/51388bb3af1b606537688c851e9d334e"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(66c927d23507f3907b4cbded78a54f68)
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 66c927d23507f3907b4cbded78a54f68

