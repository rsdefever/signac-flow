#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d2/parallel_op/0000/0542e61ca620931f978bfed6498a45e1"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 3

set -e
set -u

cd /home/johndoe/project/

# parallel_op(66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 66c927d23507f3907b4cbded78a54f68

