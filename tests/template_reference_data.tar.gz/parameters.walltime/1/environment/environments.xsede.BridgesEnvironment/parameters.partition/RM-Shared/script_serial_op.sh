#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d2/serial_op/0000/aebf9068b543518906970d0b2227eb18"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 1

set -e
set -u

cd /home/johndoe/project/

# serial_op(66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 66c927d23507f3907b4cbded78a54f68

