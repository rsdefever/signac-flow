#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f/serial_op/0000/841d5a9aaa0384e6c45ea0c9ab0d4c1d"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 0a46314f3bb21140debbc8e4af120947

