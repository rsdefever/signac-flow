#PBS -N SubmissionTe/5c02d3da/gpu_op/0000/9628da66c34b438d84fb7a976d82e656
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# gpu_op(5c02d3da683f5a590dc86cc4821c07b0)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 5c02d3da683f5a590dc86cc4821c07b0

