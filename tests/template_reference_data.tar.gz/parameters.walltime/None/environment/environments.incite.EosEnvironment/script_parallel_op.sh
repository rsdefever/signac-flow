#PBS -N SubmissionTe/5c02d3da/parallel_op/0000/675f6425a8303a0cc505e874cb93784d
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# parallel_op(5c02d3da683f5a590dc86cc4821c07b0)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 5c02d3da683f5a590dc86cc4821c07b0

