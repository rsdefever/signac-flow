#PBS -N SubmissionTe/5c02d3da/serial_op/0000/7530e956a92a244587e5fd4d1cfe3496
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(5c02d3da683f5a590dc86cc4821c07b0)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 5c02d3da683f5a590dc86cc4821c07b0

