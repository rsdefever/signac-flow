#PBS -N SubmissionTe/50d0bba0/mpi_op/0000/d9522f0f50952a45241fdb10c52db0be
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(50d0bba019db759bcdbddb9aed4cd204)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 50d0bba019db759bcdbddb9aed4cd204

