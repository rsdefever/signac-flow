#PBS -N SubmissionTe/50d0bba0/omp_op/0000/381c40bdf51cbeeaae52658ed5609d85
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(50d0bba019db759bcdbddb9aed4cd204)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 50d0bba019db759bcdbddb9aed4cd204

