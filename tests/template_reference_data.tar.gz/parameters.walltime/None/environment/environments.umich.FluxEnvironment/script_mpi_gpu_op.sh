#PBS -N SubmissionTe/a43b5a3b/mpi_gpu_op/0000/3e99b4ecc8cf54824aeabfb1b1fcb931
#PBS -V
#PBS -l nodes=5
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op a43b5a3b12e3499d4e23ba6f7ad011b1

