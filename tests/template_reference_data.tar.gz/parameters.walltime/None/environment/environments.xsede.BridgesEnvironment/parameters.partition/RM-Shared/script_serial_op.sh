#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/serial_op/0000/935b4920b1a71fd80be2c8b05f2300d9"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node 1

set -e
set -u

cd /home/johndoe/project/

# serial_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 92c6054c6acae4abd09b0055afdf157f

