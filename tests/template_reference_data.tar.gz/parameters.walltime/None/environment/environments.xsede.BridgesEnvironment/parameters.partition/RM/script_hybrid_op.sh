#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/hybrid_op/0000/dd3838d8ec48bb225813da90dfaa05f1"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 20

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(8aef86cd5a5dbb175d555864a7c91eed)
export OMP_NUM_THREADS=4
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 8aef86cd5a5dbb175d555864a7c91eed

