#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/serial_op/0000/4f562647300ac1eef58da96e0f292421"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 1

set -e
set -u

cd /home/johndoe/project/

# serial_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 8aef86cd5a5dbb175d555864a7c91eed

