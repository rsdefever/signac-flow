#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d7732/mpi_op/0000/bc77bf0636c3c315833b540939f49ba9"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(0b5d77326769c7e5c65bdcf8c303265c)
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 0b5d77326769c7e5c65bdcf8c303265c

