#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d7732/parallel_op/0000/80dba5f90886db5a21f9841800e9ddec"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/johndoe/project/

# parallel_op(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 0b5d77326769c7e5c65bdcf8c303265c

