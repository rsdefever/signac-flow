#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd586/omp_op/0000/899be9602dcef1ca833f5c97dbbc541c"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/johndoe/project/

# omp_op(216cd5860da17dc03ca7facd39d25e5c)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 216cd5860da17dc03ca7facd39d25e5c

