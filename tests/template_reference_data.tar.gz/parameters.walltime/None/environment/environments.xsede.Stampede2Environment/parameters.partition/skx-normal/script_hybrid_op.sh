#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/hybrid_op/0000/c592bb1b09496ebe7dd7e80c3724abb3"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(4a483a992889fc18663a15acdfdcacba)
export OMP_NUM_THREADS=4
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 4a483a992889fc18663a15acdfdcacba

