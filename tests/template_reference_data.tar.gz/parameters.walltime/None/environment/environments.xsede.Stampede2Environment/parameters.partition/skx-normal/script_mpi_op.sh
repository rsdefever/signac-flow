#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/mpi_op/0000/d860601bfe20d6856537760158ccdb58"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# mpi_op(4a483a992889fc18663a15acdfdcacba)
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 4a483a992889fc18663a15acdfdcacba

